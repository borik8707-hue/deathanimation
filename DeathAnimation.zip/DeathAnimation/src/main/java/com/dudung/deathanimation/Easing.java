package com.dudung.deathanimation;

enum Easing {
    LINEAR, EASE_OUT, EASE_IN_OUT;

    /** t = 0..1, hasilnya 0..1 */
    double apply(double t) {
        if (t <= 0) return 0;
        if (t >= 1) return 1;
        return switch (this) {
            case LINEAR -> t;
            case EASE_OUT -> 1 - Math.pow(1 - t, 3);
            case EASE_IN_OUT -> t * t * (3 - 2 * t);
        };
    }
}
