package com.dudung.deathanimation;

import org.bukkit.Color;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.logging.Logger;

/** Semua isi config.yml dibaca sekali di sini biar nggak baca yaml tiap tick. */
final class AnimConfig {

    final Set<String> disabledWorlds;

    // animasi
    final boolean animationEnabled, hideVanillaCorpse;
    final int riseTicks, holdTicks, poseTicks;
    final double riseHeight, spinDegrees, bobAmplitude, bobSpeed, swayDegrees, swaySpeed;
    final Easing easing;

    // pose (derajat x,y,z)
    final double[] head, body, leftArm, rightArm, leftLeg, rightLeg;

    // badan
    final boolean usePlayerHead, showHelmet, copyArmor, fallbackClothes, copyHandItems, glowBody;
    final Color fallbackColor;

    // efek
    final Sound startSound, endSound;
    final float startVolume, startPitch, endVolume, endPitch;
    final Particle trailParticle, endParticle;
    final int trailCount, endCount;

    // drops
    final boolean dropsEnabled, snapToGround, dropsInvulnerable, dropsGlow;
    final int maxGroundSearch, pickupDelay;
    final double spreadRadius;

    AnimConfig(FileConfiguration c, Logger log) {
        disabledWorlds = new HashSet<>(c.getStringList("disabled-worlds"));

        animationEnabled = c.getBoolean("animation.enabled", true);
        hideVanillaCorpse = c.getBoolean("animation.hide-vanilla-corpse", true);
        riseHeight = c.getDouble("animation.rise-height", 3.5);
        riseTicks = Math.max(1, c.getInt("animation.rise-ticks", 50));
        holdTicks = Math.max(0, c.getInt("animation.hold-ticks", 25));
        poseTicks = Math.max(1, c.getInt("animation.pose-ticks", 25));
        spinDegrees = c.getDouble("animation.spin-degrees", 120);
        bobAmplitude = c.getDouble("animation.bob.amplitude", 0.08);
        bobSpeed = c.getDouble("animation.bob.speed", 0.20);
        swayDegrees = c.getDouble("animation.sway.degrees", 5);
        swaySpeed = c.getDouble("animation.sway.speed", 0.15);
        Easing e;
        try {
            e = Easing.valueOf(c.getString("animation.easing", "EASE_IN_OUT").trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            log.warning("animation.easing nggak valid, pakai EASE_IN_OUT");
            e = Easing.EASE_IN_OUT;
        }
        easing = e;

        head = angles(c, "pose.head", new double[]{-45, 0, 0});
        body = angles(c, "pose.body", new double[]{-15, 0, 0});
        leftArm = angles(c, "pose.left-arm", new double[]{50, 0, -30});
        rightArm = angles(c, "pose.right-arm", new double[]{50, 0, 30});
        leftLeg = angles(c, "pose.left-leg", new double[]{28, 0, -4});
        rightLeg = angles(c, "pose.right-leg", new double[]{22, 0, 4});

        usePlayerHead = c.getBoolean("body.use-player-head", true);
        showHelmet = c.getBoolean("body.show-helmet", false);
        copyArmor = c.getBoolean("body.copy-armor", true);
        fallbackClothes = c.getBoolean("body.fallback-clothes", true);
        fallbackColor = parseColor(c.getString("body.fallback-color", "#1c1c1c"), Color.fromRGB(0x1c1c1c));
        copyHandItems = c.getBoolean("body.copy-hand-items", false);
        glowBody = c.getBoolean("body.glowing", false);

        startSound = sound(c.getString("effects.start-sound.name", "PARTICLE_SOUL_ESCAPE"), log);
        startVolume = (float) c.getDouble("effects.start-sound.volume", 1.5);
        startPitch = (float) c.getDouble("effects.start-sound.pitch", 1.0);
        endSound = sound(c.getString("effects.end-sound.name", "ENTITY_ENDERMAN_TELEPORT"), log);
        endVolume = (float) c.getDouble("effects.end-sound.volume", 0.6);
        endPitch = (float) c.getDouble("effects.end-sound.pitch", 1.6);
        trailParticle = particle(c.getString("effects.trail-particle.name", "SOUL"), log);
        trailCount = c.getInt("effects.trail-particle.count", 1);
        endParticle = particle(c.getString("effects.end-particle.name", "CLOUD"), log);
        endCount = c.getInt("effects.end-particle.count", 25);

        dropsEnabled = c.getBoolean("drops.enabled", true);
        snapToGround = c.getBoolean("drops.snap-to-ground", true);
        maxGroundSearch = Math.max(1, c.getInt("drops.max-ground-search", 64));
        spreadRadius = Math.max(0, c.getDouble("drops.spread-radius", 0.0));
        pickupDelay = Math.max(0, c.getInt("drops.pickup-delay-ticks", 20));
        dropsInvulnerable = c.getBoolean("drops.invulnerable", true);
        dropsGlow = c.getBoolean("drops.glowing", false);
    }

    private static double[] angles(FileConfiguration c, String path, double[] def) {
        List<Double> l = c.getDoubleList(path);
        if (l.size() != 3) return def;
        return new double[]{l.get(0), l.get(1), l.get(2)};
    }

    private static Color parseColor(String s, Color def) {
        try {
            String h = s.startsWith("#") ? s.substring(1) : s;
            return Color.fromRGB(Integer.parseInt(h, 16));
        } catch (Exception ex) {
            return def;
        }
    }

    private static Sound sound(String name, Logger log) {
        if (name == null || name.isBlank() || name.equalsIgnoreCase("NONE")) return null;
        try {
            return Sound.valueOf(name.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            log.warning("Sound nggak dikenal: " + name);
            return null;
        }
    }

    private static Particle particle(String name, Logger log) {
        if (name == null || name.isBlank() || name.equalsIgnoreCase("NONE")) return null;
        try {
            Particle p = Particle.valueOf(name.trim().toUpperCase(Locale.ROOT));
            if (p.getDataType() != Void.class) {
                log.warning("Particle " + name + " butuh data tambahan, nggak didukung. Pakai yang lain.");
                return null;
            }
            return p;
        } catch (IllegalArgumentException ex) {
            log.warning("Particle nggak dikenal: " + name);
            return null;
        }
    }
}
