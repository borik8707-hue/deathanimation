package com.dudung.deathanimation;

import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class DeathAnimationPlugin extends JavaPlugin implements Listener, TabExecutor {

    private AnimConfig cfg;
    private final Set<DeathAnimation> running = new HashSet<>();
    private final Set<UUID> hidden = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        cfg = new AnimConfig(getConfig(), getLogger());
        Bukkit.getPluginManager().registerEvents(this, this);
        if (getCommand("deathanim") != null) {
            getCommand("deathanim").setExecutor(this);
        }
    }

    @Override
    public void onDisable() {
        for (DeathAnimation a : new ArrayList<>(running)) a.stopNow();
        for (UUID id : new ArrayList<>(hidden)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) revealCorpse(p);
        }
        hidden.clear();
    }

    void track(DeathAnimation a) {
        running.add(a);
    }

    void untrack(DeathAnimation a) {
        running.remove(a);
    }

    // ------------------------------------------------------------------ events

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        if (p.hasPermission("deathanimation.bypass")) return;
        if (cfg.disabledWorlds.contains(p.getWorld().getName())) return;
        Location loc = p.getLocation();

        if (cfg.dropsEnabled && !e.getDrops().isEmpty()) {
            List<ItemStack> items = new ArrayList<>(e.getDrops());
            e.getDrops().clear();
            spawnPile(loc, items);
        }

        if (cfg.animationEnabled) {
            DeathAnimation.play(this, cfg, loc, p);
            if (cfg.hideVanillaCorpse) hideCorpse(p);
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> revealCorpse(p), 2L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        revealCorpse(e.getPlayer());
    }

    // ------------------------------------------------------------------ corpse

    private void hideCorpse(Player dead) {
        hidden.add(dead.getUniqueId());
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (!viewer.equals(dead)) viewer.hideEntity(this, dead);
        }
    }

    private void revealCorpse(Player p) {
        if (!hidden.remove(p.getUniqueId())) return;
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (!viewer.equals(p)) viewer.showEntity(this, p);
        }
    }

    // ------------------------------------------------------------------ drops

    private void spawnPile(Location from, List<ItemStack> items) {
        World w = from.getWorld();
        if (w == null) return;
        Location pile = pileLocation(from);
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        for (ItemStack it : items) {
            if (it == null || it.getType().isAir()) continue;
            Location at = pile.clone();
            if (cfg.spreadRadius > 0) {
                double ang = rnd.nextDouble(Math.PI * 2);
                double r = Math.sqrt(rnd.nextDouble()) * cfg.spreadRadius;
                at.add(Math.cos(ang) * r, 0, Math.sin(ang) * r);
            }
            w.dropItem(at, it, item -> {
                item.setVelocity(new Vector(0, 0, 0)); // timpa "loncatan" random bawaan
                item.setPickupDelay(cfg.pickupDelay);
                item.setInvulnerable(cfg.dropsInvulnerable);
                item.setGlowing(cfg.dropsGlow);
            });
        }
    }

    private Location pileLocation(Location from) {
        World w = from.getWorld();
        if (cfg.snapToGround && w != null) {
            RayTraceResult r = w.rayTraceBlocks(from.clone().add(0, 0.3, 0), new Vector(0, -1, 0),
                    cfg.maxGroundSearch, FluidCollisionMode.NEVER, true);
            if (r != null) {
                return new Location(w, from.getX(), r.getHitPosition().getY() + 0.1, from.getZ());
            }
        }
        return from.clone();
    }

    // ------------------------------------------------------------------ command

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0) {
            s.sendMessage("/deathanim <reload|test>");
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                if (!s.hasPermission("deathanimation.admin")) {
                    s.sendMessage("Nggak punya izin.");
                    return true;
                }
                reloadConfig();
                cfg = new AnimConfig(getConfig(), getLogger());
                s.sendMessage("Config DeathAnimation di-reload.");
            }
            case "test" -> {
                if (!s.hasPermission("deathanimation.admin")) {
                    s.sendMessage("Nggak punya izin.");
                    return true;
                }
                if (!(s instanceof Player p)) {
                    s.sendMessage("Command ini cuma buat player.");
                    return true;
                }
                DeathAnimation.play(this, cfg, p.getLocation(), p);
            }
            default -> s.sendMessage("/deathanim <reload|test>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        if (a.length == 1) return List.of("reload", "test");
        return List.of();
    }
}
