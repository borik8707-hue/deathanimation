package com.dudung.deathanimation;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.EulerAngle;

/**
 * Satu animasi mati = satu ArmorStand yang di-update tiap tick:
 * posisi naik (di-ease), pose di-blend dari pose default ke pose kayang, plus goyang halus.
 */
final class DeathAnimation extends BukkitRunnable {

    // pose default armor stand (derajat)
    private static final double[] REST_HEAD = {0, 0, 0};
    private static final double[] REST_BODY = {0, 0, 0};
    private static final double[] REST_LARM = {-10, 0, -10};
    private static final double[] REST_RARM = {-15, 0, 10};
    private static final double[] REST_LLEG = {-1, 0, -1};
    private static final double[] REST_RLEG = {1, 0, 1};

    private final DeathAnimationPlugin plugin;
    private final AnimConfig cfg;
    private final Location origin;
    private final ArmorStand stand;
    private final int totalTicks;
    private int tick = 0;

    private DeathAnimation(DeathAnimationPlugin plugin, AnimConfig cfg, Location origin, ArmorStand stand) {
        this.plugin = plugin;
        this.cfg = cfg;
        this.origin = origin;
        this.stand = stand;
        this.totalTicks = cfg.riseTicks + cfg.holdTicks;
    }

    static void play(DeathAnimationPlugin plugin, AnimConfig cfg, Location loc, Player model) {
        World world = loc.getWorld();
        if (world == null) return;
        Location spawn = loc.clone();
        spawn.setPitch(0);

        ArmorStand stand = world.spawn(spawn, ArmorStand.class, s -> setup(s, cfg, model));
        DeathAnimation anim = new DeathAnimation(plugin, cfg, spawn, stand);
        plugin.track(anim);
        anim.runTaskTimer(plugin, 0L, 1L);

        if (cfg.startSound != null) {
            world.playSound(spawn, cfg.startSound, cfg.startVolume, cfg.startPitch);
        }
    }

    private static void setup(ArmorStand s, AnimConfig cfg, Player model) {
        s.setPersistent(false);
        s.setInvulnerable(true);
        s.setGravity(false);
        s.setSilent(true);
        s.setBasePlate(false);
        s.setArms(true);
        s.setMarker(true);
        s.setCollidable(false);
        s.setGlowing(cfg.glowBody);

        EntityEquipment eq = s.getEquipment();
        if (eq == null) return;
        PlayerInventory inv = model != null ? model.getInventory() : null;

        ItemStack helmet = null;
        if (cfg.showHelmet && inv != null && notAir(inv.getHelmet())) {
            helmet = inv.getHelmet().clone();
        }
        if (helmet == null && cfg.usePlayerHead) {
            helmet = skull(model);
        }
        eq.setHelmet(helmet);
        eq.setChestplate(piece(cfg, inv != null ? inv.getChestplate() : null, Material.LEATHER_CHESTPLATE));
        eq.setLeggings(piece(cfg, inv != null ? inv.getLeggings() : null, Material.LEATHER_LEGGINGS));
        eq.setBoots(piece(cfg, inv != null ? inv.getBoots() : null, Material.LEATHER_BOOTS));

        if (cfg.copyHandItems && inv != null) {
            if (notAir(inv.getItemInMainHand())) eq.setItemInMainHand(inv.getItemInMainHand().clone());
            if (notAir(inv.getItemInOffHand())) eq.setItemInOffHand(inv.getItemInOffHand().clone());
        }
    }

    private static boolean notAir(ItemStack i) {
        return i != null && !i.getType().isAir();
    }

    private static ItemStack skull(Player model) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        if (model != null && skull.getItemMeta() instanceof SkullMeta meta) {
            meta.setOwningPlayer(model);
            skull.setItemMeta(meta);
        }
        return skull;
    }

    private static ItemStack piece(AnimConfig cfg, ItemStack real, Material fallback) {
        if (cfg.copyArmor && notAir(real)) return real.clone();
        if (cfg.fallbackClothes) {
            ItemStack item = new ItemStack(fallback);
            if (item.getItemMeta() instanceof LeatherArmorMeta meta) {
                meta.setColor(cfg.fallbackColor);
                item.setItemMeta(meta);
            }
            return item;
        }
        return null;
    }

    @Override
    public void run() {
        if (!stand.isValid()) {
            finish(false);
            return;
        }
        if (tick >= totalTicks) {
            finish(true);
            return;
        }

        // --- posisi ---
        double rise = cfg.easing.apply(tick / (double) cfg.riseTicks);
        double y = cfg.riseHeight * rise + cfg.bobAmplitude * Math.sin(tick * cfg.bobSpeed) * rise;
        Location l = origin.clone().add(0, y, 0);
        l.setYaw((float) (origin.getYaw() + cfg.spinDegrees * rise));
        stand.teleport(l);

        // --- pose ---
        double p = cfg.easing.apply(tick / (double) cfg.poseTicks);
        double sway = cfg.swayDegrees * Math.sin(tick * cfg.swaySpeed) * p;
        stand.setHeadPose(blend(REST_HEAD, cfg.head, p, sway * 0.5, 0, 0));
        stand.setBodyPose(blend(REST_BODY, cfg.body, p, 0, 0, 0));
        stand.setLeftArmPose(blend(REST_LARM, cfg.leftArm, p, 0, 0, -sway));
        stand.setRightArmPose(blend(REST_RARM, cfg.rightArm, p, 0, 0, sway));
        stand.setLeftLegPose(blend(REST_LLEG, cfg.leftLeg, p, sway, 0, 0));
        stand.setRightLegPose(blend(REST_RLEG, cfg.rightLeg, p, -sway, 0, 0));

        // --- efek ---
        if (cfg.trailParticle != null && cfg.trailCount > 0) {
            stand.getWorld().spawnParticle(cfg.trailParticle, l.clone().add(0, 1.0, 0),
                    cfg.trailCount, 0.25, 0.4, 0.25, 0.0);
        }
        tick++;
    }

    private static EulerAngle blend(double[] from, double[] to, double p, double dx, double dy, double dz) {
        return new EulerAngle(
                Math.toRadians(from[0] + (to[0] - from[0]) * p + dx),
                Math.toRadians(from[1] + (to[1] - from[1]) * p + dy),
                Math.toRadians(from[2] + (to[2] - from[2]) * p + dz));
    }

    private void finish(boolean natural) {
        if (natural && stand.isValid()) {
            Location at = stand.getLocation().add(0, 1.0, 0);
            World w = at.getWorld();
            if (w != null) {
                if (cfg.endParticle != null && cfg.endCount > 0) {
                    w.spawnParticle(cfg.endParticle, at, cfg.endCount, 0.4, 0.6, 0.4, 0.02);
                }
                if (cfg.endSound != null) {
                    w.playSound(at, cfg.endSound, cfg.endVolume, cfg.endPitch);
                }
            }
        }
        stopNow();
    }

    /** Dipanggil juga dari onDisable. */
    void stopNow() {
        try {
            cancel();
        } catch (IllegalStateException ignored) {
            // belum/ sudah nggak terjadwal
        }
        stand.remove();
        plugin.untrack(this);
    }
}
