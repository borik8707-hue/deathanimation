# DeathAnimation (Paper 1.20.1, Java 17)

Build:   mvn clean package
Hasil:   target/DeathAnimation-1.0.0.jar  -> taruh di folder plugins/ server, restart.

Command:
  /deathanim test     coba animasi tanpa mati (perlu permission deathanimation.admin / OP)
  /deathanim reload   reload config.yml

Tuning pose: edit bagian `pose:` di plugins/DeathAnimation/config.yml, lalu /deathanim reload dan /deathanim test.
